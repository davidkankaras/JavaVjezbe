package projekat_4;

interface Attacker {

	int getEffectiveDamage();
	
}
