package projekat_4;

interface Collidable {
	boolean intersects(Collidable other);

}
